//
//  SceneDelegate.h
//  Producer_Comsumer_UI
//
//  Created by Liu_zc on 2021/1/6.
//  Copyright © 2021 Liu_zc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

